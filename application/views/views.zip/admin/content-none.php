<div class="row" id="page-header">
    <div class="col-md-6 col-lg-8 ">
        <h1><?=$title;?></h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!--End header-->