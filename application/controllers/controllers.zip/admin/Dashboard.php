<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {
    public function __construct() {
        parent::__construct();
        
    }
	public function index()
	{
            $data=$this->data;
            $total_users=$this->M_users->get_total();
            if(!$total_users){
                $total_users=0;
            }
            $this->load->model("M_posts");
            $total_posts=$this->M_posts->get_total();
            if(!$total_posts){
                $total_posts=0;
            }
            $data=array(
                'title'=>'Tổng quan hệ thống',
                'template'=>'dashboard',
                'script'=>'',
                'style'=>'',
                'total_users'=>$total_users,
                'total_posts'=>$total_posts,
            );
            $this->load->view('admin/master-page',$data);
	}
}
