<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined("BASEPATH") OR exit("No Access");
class Productions extends MY_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model("M_productions");
        $this->load->model("M_groups");
        $this->load->model("M_cities");
    }
    public function index(){
        $data=$this->data;
        $input=array();
        $input['select']="id,title";
        $list=$this->M_productions->get_list();
        $data=array(
            'title'=>"Danh sách tin bất động sản",
            'template'=>'productions/list',
            'list'=>$list,
        );
        $this->load->view('admin/master-page',$data);
    }
   
    public function switch_status($id=0){
        $item=$this->M_productions->get_item($id);
        if(!$item){
            $this->_msg_admin("warning", "Nội dung này không tồn tại trong hệ thống");
        }else{
            $tmp=array(
                'status'=>-$item->status
            );
            if($this->M_productions->update($id,$tmp)){
                $this->_msg_admin("success", "Cập nhật trạng thái thành công");
            }else{
                 $this->_msg_admin("danger", "Cập nhật trạng thái thất bại");
            }
        }
        redirect(base_url()."admin/productions");
    }
    public function delete_all($id=0){
        if($this->M_posts->delete($id)){
            echo 1;
        }else{
            echo 0;
        }
    }
    public function delete_item($id=0){
        if($this->M_productions->delete($id)){
             $this->_msg_admin("success", "Xóa thành công");
        }else{
             $this->_msg_admin("danger", "Xóa không thành công");
        }
        redirect(base_url()."admin/productions");
    }
 
}