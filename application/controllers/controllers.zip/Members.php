<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
	public function index()
	{
            $data=array(
                'title'=>"Thành viên - Trang thông tin mua bán, cho thuê nhà đất tại Việt Nam",
                'description'=>"www.batdongsanflan.com  website đăng tin mua bán rao vặt cho thuê bất động sản, nhà đất tại Việt Nam",
                'page'=>'member/account',
                
            );
            $this->load->view('site/master-page',$data);
	}